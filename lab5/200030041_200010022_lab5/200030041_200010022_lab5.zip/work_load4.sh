#!/bin/sh
./arithoh.sh &
./syscall.sh &
./arithoh.sh &
./syscall.sh &
./arithoh.sh &
./syscall.sh &
wait
