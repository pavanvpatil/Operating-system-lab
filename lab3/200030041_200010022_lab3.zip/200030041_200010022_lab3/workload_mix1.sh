#!/bin/sh
./fstime.sh &
./pipe.sh &
wait
