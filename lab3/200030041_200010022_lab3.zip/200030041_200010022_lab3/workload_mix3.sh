#!/bin/sh
./spawn.sh &
./syscall.sh &
wait
