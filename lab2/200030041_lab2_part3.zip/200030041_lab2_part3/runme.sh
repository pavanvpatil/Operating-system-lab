 #!/bin/bash
 cp ./forkexit.c /usr/src/minix/servers/pm
 cd /usr/src/
 make build MKUPDATE=yes
